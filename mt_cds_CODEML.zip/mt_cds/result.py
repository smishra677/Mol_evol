from Bio.Phylo.PAML import codeml
import pandas as pd
lis_ds=[]
lis_dn=[]
file_name=[]
for i in range(13):
	resul_f= "results_mt_cds_"+str(i)+".out"
	results = codeml.read(resul_f)
	file_name.append("results_mt_cds_"+str(i))
	lis_ds.append(results['NSsites'][0]['parameters']['dS'])
	lis_dn.append(results['NSsites'][0]['parameters']['dN'])
li1= {'DN':lis_dn,'DS':lis_ds,'file_name':file_name}
df1 = pd.DataFrame(li1)
print(df1)
df1.to_csv('MT_CDS_DN_DS.csv', sep=',')