

from Bio.Phylo.PAML import codeml
for i in range(13):
	alignment= 'mt_cds_'+str(i)+'_NT_NT.fa'
	cml = codeml.Codeml()
	cml.read_ctl_file("codeml.ctl")
	cml.alignment = alignment
	cml.out_file = "results_mt_cds_"+str(i)+".out"
	cml.working_dir = "./Results/"

	#results = codeml.read('results.out')
	#print(results)
	cml.run()


