import os

import glob

list_of_files = filter( os.path.isfile,
                        glob.glob('./' + '*') )
  
list_of_files= ['AP3M2-201_NT_NT.fasta','CDK14-202_NT_NT.fasta','CKMT1B-201_NT_NT.fasta','APC2-201_NT_NT.fasta','ARMC10-202_NT_NT.fasta','ATOH8-201_NT_NT.fasta','BNIP1-201_NT_NT.fasta','BTF3-202_NT_NT.fasta','C17orf50-201_NT_NT.fasta','CCDC152-201_NT_NT.fasta']
#list_of_files = sorted( list_of_files,key =  lambda x: os.stat(x).st_size)

from Bio.Phylo.PAML import codeml
for i in list_of_files:
	alignment= str(i)
	print(alignment)
	cml = codeml.Codeml()
	cml.read_ctl_file("codeml.ctl")
	cml.alignment = alignment
	cml.out_file = "results_NU_cds_"+str(i)[2:]+".out"
	cml.working_dir = "./Results/"

	#results = codeml.read('results.out')
	#print(results)
	cml.run()


