import os

import phyphy
	
myhyphy = phyphy.HyPhy(executable   = "/usr/local/bin/hyphy",
                       mpi_launcher = "mpirun",
                       mpi_options  = "-np 32")

tree= open('tree.nwk').read()
tree = 'BEGIN TREES; \n TREE tree =' +tree+'\n END;'
li = os.listdir()
ope_=open('err.txt','w+')
for i in li:
	try:
		file1= str(i)
		os.system('java -jar macse_v2.07.jar -prog  alignSequences -seq '+file1)
		file = str(i)[:-6]+'_NT.fasta'
		os.system('java -jar macse_v2.07.jar -prog exportAlignment -align '+file+' -codonForFinalStop --- -codonForInternalStop NNN')

		alignment= str(i)[:-6]+'_NT_NT.fasta'
		ali =open(alignment,'r')
		ali1= ali.read()
		ali.close()
		ali =open(alignment,'w+')
		ali1= ali1.replace("!", "N")
		ali.write(ali1)
		ali.close()
		os.system('seqconverter -I fasta -O nexus '+alignment+' > myalignment_'+alignment+'.nexus')

		nexus = open('myalignment_'+alignment+'.nexus','r')
		nexus1= nexus.read()
		nexus.close()
		nexus =open('myalignment_'+alignment+'.nexus','w+')
		nexus1 = nexus1+'\n'+tree
		nexus.write(nexus1)
		nexus.close()
		os.system('hyphy -fel myalignment_'+alignment+'.nexus')
		#myfel = phyphy.FEL(hyphy = myhyphy,data =  'myalignment_'+alignment+'.nexus', nexus=True)
		#myfel.run_analysis()

	except:
		ope_.write('Hello World!')

ope_.close()



