from Bio.Phylo.PAML import codeml
lis_ds=[]
lis_dn=[]
for i in range(6):
	resul_f= "results_mt_cds_"+str(i)+".out"
	results = codeml.read(resul_f)
	lis_ds.append(results['NSsites'][0]['parameters']['dS'])
	lis_dn.append(results['NSsites'][0]['parameters']['dN'])

print(lis_ds)
print(lis_dn)