import os
import pandas as pd
li = os.listdir()
from Bio.Phylo.PAML import codeml
lis_ds=[]
lis_dn=[]
file_name=[]
for i in li:
	print(i)
	if ('results_' in i) and ('.py' not in i):
		try:
			resul_f= i
			print(resul_f)
			results = codeml.read(resul_f)
			
			lis_ds.append(results['NSsites'][0]['parameters']['dS'])
			lis_dn.append(results['NSsites'][0]['parameters']['dN'])
			file_name.append(str(i))
		except:
			print('err')

print(file_name)
li1= {'DN':lis_dn,'DS':lis_ds,'file_name':file_name}
df1 = pd.DataFrame(li1)
print(df1)
df1.to_csv('NU_CDS_DN_DS.csv', sep=',')
